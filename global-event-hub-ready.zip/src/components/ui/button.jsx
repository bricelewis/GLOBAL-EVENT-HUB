export function Button({ children, onClick, className = "", variant = "default" }) {
  const base = "px-4 py-2 rounded-2xl font-semibold flex justify-center items-center";
  const variants = {
    default: "bg-blue-600 text-white hover:bg-blue-700",
    outline: "border border-blue-600 text-blue-600 hover:bg-blue-50",
    secondary: "bg-gray-100 text-gray-800 hover:bg-gray-200"
  };
  return (
    <button onClick={onClick} className={`${base} ${variants[variant]} ${className}`}>
      {children}
    </button>
  );
}