// Placeholder component – update or integrate real date picker if needed
export function Calendar({}) {
  return <div className="text-gray-500">[Calendar placeholder]</div>;
}