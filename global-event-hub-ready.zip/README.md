# Global Event Hub

A simple React app to add and display global events, built with Firebase Firestore and deployed with Vercel.

## Features
- Add event with title, location, and date
- Live update from Firebase Firestore
- Clean, modern UI using custom components

## How to Run
1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

## Deployment
Recommended: [Vercel](https://vercel.com)

---

© 2025 Global Event Hub